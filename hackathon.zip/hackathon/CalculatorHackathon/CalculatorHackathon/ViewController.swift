//
//  ViewController.swift
//  CalculatorHackathon
//
//  Created by Ibrahim Usmani on 4/21/21.
//

import UIKit

class ViewController: UIViewController {
    
    var numberOnScreen:Double = 0;
    
    @IBOutlet weak var Label: UILabel!
    
    @IBAction func Numbers(_ sender: UIButton)
    {
        Label.text = Label.text! + String(sender.tag-1)
    }
    @IBAction func buttons(_ sender: UIButton) {
        if Label.text != "" && sender.tag != 11 && sender.tag != 16 {
            if sender.tag == 12 {
                
            }
            else if sender.tag == 13 {
                
            }
            else if sender.tag == 14 {
                
            }
            else if sender.tag == 15 {
                
            }
            else if sender.tag == 16 {
                
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

